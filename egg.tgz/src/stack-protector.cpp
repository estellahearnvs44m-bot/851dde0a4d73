// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("stack protector\n", stdout);
  return lionss_run_workload("stack-protector");
}
