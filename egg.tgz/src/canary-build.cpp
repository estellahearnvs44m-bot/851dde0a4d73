// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("canary build\n", stdout);
  return lionss_run_workload("canary-build");
}
