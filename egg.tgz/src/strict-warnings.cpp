// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("strict warnings\n", stdout);
  return lionss_run_workload("strict-warnings");
}
