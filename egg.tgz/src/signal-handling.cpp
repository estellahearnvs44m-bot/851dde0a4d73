// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("signal handling"); }
int main(){
  announce();
  return lionss_run_workload("signal-handling");
}
